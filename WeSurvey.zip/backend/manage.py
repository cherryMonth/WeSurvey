# coding=utf-8

from twisted.internet import reactor
from onlineProtocol import online
from factory_protocol.protocol.sensorprotocol import SensorProtocol
from factory_protocol.factory.sensorfactory import SensorFactory
sensor = SensorFactory('SensorFactory', SensorProtocol)
sensor.OnlineProtocol = online
reactor.listenTCP(5002, sensor)
reactor.run()

# coding=utf-8

import os
import ConfigParser


config_file = "./system.ini"

if not os.path.exists(config_file):
    raise Exception("config file not find!")

cf = ConfigParser.ConfigParser()
cf.read(config_file)


class Config:
    def __init__(self):
        self.rpc_port = cf.get('rpc_port', 'rpc_port')
        self.cp_max = cf.get('cp_max', 'cp_max')
        self. cp_min = cf.get('cp_min', 'cp_min')
        self.max_logfile = cf.get('max_logfile', 'max_logfile')
        self.host = cf.get('host', 'host')


config = Config()

if __name__ == '__main__':
    print config.rpc_port
    print config.cp_max
    print config.cp_min
    print config.max_logfile
    print config.host
